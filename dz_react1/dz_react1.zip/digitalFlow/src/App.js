import Footer from "./components/Footer/Footer";
import Header from "./components/Header/Header";
import Services from "./components/Services/Services";
import './scss/style.scss'
import React, {useState}

function App() {
  
  return (
    <>
    
     {/* <Header/> */}
     <main>
      <Services/>
     </main>
     {/* <Footer/> */}
    </>
  );
}

export default App;
