import React from 'React'

const Questions = () => {
    return(
        <section className='Quection'>
            <div className='container'>
                <div className='quection_title'>
                    <div className='quection_row'>
                        <div className='quection_accordion'>
                            <div className='quection_acardion-quest'>
                                <p>сколько раз в год можно оброщатся к терапету или педиатору по данной программе</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}