import Icon1 from '../assets/services/1.svg'
import Icon2 from '../assets/services/2.svg'
import Icon3 from '../assets/services/3.svg'
import Icon4 from '../assets/services/4.svg'
import Icon5 from '../assets/services/5.svg'
import Icon6 from '../assets/services/6.svg'
import Icon7 from '../assets/services/7.svg'
import Icon8 from '../assets/services/8.svg'
import Icon9 from '../assets/services/9.svg'
import Icon10 from '../assets/services/10.svg'
import Icon11 from '../assets/services/11.svg'
import Icon12 from '../assets/services/12.svg'

export const servicesData = [
    {id: 1, text: 'Высокий уровень исполнения', icon: Icon1 },
    {id: 2, text: 'Гарантируем качество работы', icon: Icon2 },
    {id: 3, text: 'Выполним работу быстро', icon: Icon3 },
    {id: 4, text: 'Обеспечим поток заявок', icon: Icon4 },
    {id: 5, text: 'Автоматизируем работу ', icon: Icon5 },
    {id: 6, text: 'Разработаем уникальный дизайн', icon: Icon6 },
    {id: 7, text: 'Напишем чистыйкод', icon: Icon7 },
    {id: 8, text: 'Контекстная реклама', icon: Icon8 },
    {id: 9, text: 'Третированная реклама ', icon: Icon9 },
    {id: 10, text: 'SEO продвижение', icon: Icon10 },
    {id: 11, text: 'Продвижение в социальных сетях', icon: Icon11 },
    {id: 12, text: 'Высокий уровень исполнения', icon: Icon12 }
]